使用说明
先安装node
 
1、 cmd进入目录  npm install                                                                                  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　
2、 然后输入：   npm run start 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　
3、浏览器输入： http://localhost:8080

4、 抓取文章地址：
http://www.duwenzhang.com/wenzhang/aiqingwenzhang/20070628/1.html 
http://www.duwenzhang.com/wenzhang/jingdianwenzhang/yuju/20150115/315118.html
http://www.duwenzhang.com/wenzhang/renshengzheli/ganwu/20180523/389040.html
http://www.duwenzhang.com/wenzhang/jingdianwenzhang/yuju/20140910/302175.html
http://www.duwenzhang.com/wenzhang/lizhiwenzhang/20180608/389679.html
http://www.duwenzhang.com/wenzhang/yingyuwenzhang/20130519/255870.html
http://www.duwenzhang.com/wenzhang/youqingwenzhang/20160625/354561.html
http://www.duwenzhang.com/wenzhang/renshengzheli/ganwu/20180325/386809.html


注意：抓取某个网站某个页面内容可以查看该页面的dom结构获取相应内容
